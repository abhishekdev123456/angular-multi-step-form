import { NgModule }           from '@angular/core';
import { FormsModule }        from '@angular/forms';
import { CommonModule } from '@angular/common';
import { NavbarComponent }    from './navbar/navbar.component';

/* Feature Components */
import { PersonalComponent }  from './personal/personal.component';
import { WorkComponent }      from './work/work.component';
import { AddressComponent }   from './address/address.component';
import { ResultComponent }    from './result/result.component';
import { AccountFormComponent } from './account-form.component';
/* Routing Module */
import { AccountFormRoutingModule }   from './account-form.routing';

/* Shared Service */
import { FormDataService }    from './data/formData.service';
import { WorkflowService }    from './workflow/workflow.service';

@NgModule({
    imports:      [ 
                    FormsModule,
                    AccountFormRoutingModule,
                    CommonModule
                  ],
    providers:    [FormDataService ,
                   WorkflowService ],
    declarations: [ AccountFormComponent, NavbarComponent, PersonalComponent, WorkComponent, AddressComponent, ResultComponent ]
})

export class AccountFormModule {}