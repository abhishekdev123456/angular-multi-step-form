import { NgModule }             from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PersonalComponent }    from './personal/personal.component';
import { WorkComponent }        from './work/work.component';
import { AddressComponent }     from './address/address.component';
import { ResultComponent }      from './result/result.component';
import { AccountFormComponent } from './account-form.component';
import { WorkflowGuard }        from './workflow/workflow-guard.service';
import { WorkflowService }      from './workflow/workflow.service';


export const appRoutes: Routes = [
    {
        path: '',
        component: AccountFormComponent,
        children: [{
          path: '',
          children: [
            { path: '', redirectTo: 'personal', pathMatch: 'full' },
            {  path: 'personal', component: PersonalComponent },
            {  path: 'work', component: WorkComponent, canActivate: [WorkflowGuard] },
            {  path: 'address', component: AddressComponent, canActivate: [WorkflowGuard] },
            {  path: 'result', component: ResultComponent, canActivate: [WorkflowGuard] }
          ]
        }]
      }
];

@NgModule({
  imports: [RouterModule.forChild(appRoutes)],
  exports: [RouterModule],
  providers: [WorkflowGuard]
})

export class AccountFormRoutingModule {}