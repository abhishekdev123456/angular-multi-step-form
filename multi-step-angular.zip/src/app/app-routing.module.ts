import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


const routes: Routes = [
  {path:'', redirectTo:'account-opening', pathMatch:'full'},
  {path:'account-opening', loadChildren:()=>import(`../account-opening/account-form.module`).then(m=>m.AccountFormModule)},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
